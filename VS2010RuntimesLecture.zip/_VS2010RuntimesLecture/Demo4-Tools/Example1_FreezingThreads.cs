﻿// ==========
// EXAMPLE #1
// ==========
// Goal:
// Find the bug in IsPrime.  At least one small non-prime is being incorrectly categorized as a prime.
// 
// Ref:  http://msdn.microsoft.com/en-us/magazine/ee410778.aspx
// 
// Steps:
// 1. Run and see that some non-primes are output (e.g. 9)
// 2. Set a conditional breakpoint in IsPrime for when numberToTest==9
// 3. When the breakpoint is hit, use the Parallel Tasks window to Freeze All Threads But This
// 4. Step through to find the bug

using System;
using System.Linq;

class Example1_FreezingThreads
{
  public static void Run()
  {
    // Parallel LINQ Example - Test numbers in range for Prime...
    var primes = from n in Enumerable.Range(1, 1000).AsParallel().AsOrdered().WithMergeOptions(ParallelMergeOptions.NotBuffered)
                 where IsPrime(n)    // <<< TEST PRIME
                 select n;
    foreach (var prime in primes) Console.WriteLine(prime);
    Console.ReadLine();
  }

  public static bool IsPrime(int numberToTest)
  {
    if (numberToTest == 2) return true;
    if (numberToTest < 2 || (numberToTest & 1) == 0) return false;

    int upperBound = (int)Math.Sqrt(numberToTest);   // <<< Set Conditional BP, Freeze all but current thread
    for (int i = 3; i < upperBound; i++)
    {
      if ((numberToTest % i) == 0) return false;
    }
    return true;
  }
}