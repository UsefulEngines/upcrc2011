﻿// ==========
// EXAMPLE #2
// ==========
// Goal:
// Find the bug.  Some work is getting run before its dependencies are complete. Why?
// 
// Steps:
// 1. Run and wait for the debugger to break in.
// 2. View the Parallel Tasks window.  Note which tasks are scheduled.

using System.Threading;
using System.Threading.Tasks;

class Example2_ScheduledTasks
{
  public static void Run()
  {
    var step1a = Task.Factory.StartNew(state => Step1a(), "Step1a");   // note: Use state object to name each task;
    var step1b = Task.Factory.StartNew(state => Step1b(), "Step1b");   // state shows-up in Debugger-ParallelTasks
    var step1c = Task.Factory.StartNew(state => Step1c(), "Step1c");   // window and also via "step1x.AsyncState".

    Task.WaitAll(step1a, step1b, step1c);

    var step2a = Task.Factory.StartNew(state => Step2a(), "Step2a");
    var step2b = Task.Factory.StartNew(state => Step2b(), "Step2b");
    var step2c = Task.Factory.StartNew(state => Step2c(), "Step2c");

    Task.WaitAll(step2a, step1b, step1c);

    var step3a = Task.Factory.StartNew(state => Step3a(), "Step3a");
    var step3b = Task.Factory.StartNew(state => Step3b(), "Step3b");
    var step3c = Task.Factory.StartNew(state => Step3c(), "Step3c");

    Watchdog.Break();
    Task.WaitAll(step3a, step3b, step3c);
  }

  static void Step1a() { Thread.SpinWait(WORK); }
  static void Step1b() { Thread.SpinWait(WORK); }
  static void Step1c() { Thread.SpinWait(WORK); }

  static void Step2a() { Thread.SpinWait(WORK); }
  static void Step2b() { Thread.SpinWait(WORK); }
  static void Step2c() { Thread.SpinWait(WORK); }

  static void Step3a() { Thread.SpinWait(WORK); }
  static void Step3b() { Thread.SpinWait(WORK); }
  static void Step3c() { Thread.SpinWait(WORK); }

  const int WORK = 40000000;
}