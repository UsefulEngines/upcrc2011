﻿// ==========
// EXAMPLE #4
// ==========
// Goal:
// Find the performance bottleneck.  We're going on a convoy!
//
// Steps:
// 1. Run, and wait for the debugger to break in.
// 2. Observe in the Parallel Stacks window where all of the "Demo" threads are blocked

using System.Linq;
using System.Threading;

class Example4_LockConvy
{
  public static void Run()
  {
    //Watchdog.BreakIn(3000);

    object obj = new object();

    Enumerable.Range(1, 10).Select(i =>
    {
      var t = new Thread(() =>
      {
        while (true)
        {
          DoWork();
          lock (obj) DoProtectedWork();
        }
      }) { Name = "Demo " + i };
      t.Start();
      return t;
    }).ToList().ForEach(t => t.Join());
  }

  private static void DoWork() { Thread.Sleep(100); }
  private static void DoProtectedWork() { Thread.Sleep(200); }
}