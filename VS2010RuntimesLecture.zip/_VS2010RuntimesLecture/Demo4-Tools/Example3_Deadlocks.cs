﻿// ==========
// EXAMPLE #3
// ==========
// Goal:
// Find the source of the deadlocks.
//
// Steps:
// 1. Run and wait for the debugger to break in.
// 2. Observe the Parallel Tasks window and what each Task is blocked on.

using System.Threading.Tasks;

class Example3_Deadlocks
{
  public static void Run()
  {
    int transfersCompleted = 0;
    Watchdog.BreakIfRepeats(() => transfersCompleted, 500);

    BankAccount a = new BankAccount { Balance = 1000 };
    BankAccount b = new BankAccount { Balance = 1000 };
    while (true)
    {
      Parallel.Invoke(
          () => Transfer(a, b, 100),
          () => Transfer(b, a, 100));
      transfersCompleted += 2;
    }
  }

  class BankAccount { public int Balance; }

  static void Transfer(BankAccount one, BankAccount two, int amount)
  {
    lock (one)
    {
      lock (two) // BUG: lock ordering
      {
        one.Balance -= amount;
        two.Balance += amount;
      }
    }
  }
}