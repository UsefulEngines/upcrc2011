﻿//--------------------------------------------------------------------------
// 
//  Copyright (c) Microsoft Corporation.  All rights reserved. 
// 
//  File: Program.cs
//
//--------------------------------------------------------------------------

using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

class Program
{
    const int num_steps = 100000000;

    /// <summary>Main method to time various implementations of computing PI.</summary>
    static void Main(string[] args)
    {
        try
        {
            while (true)
            {
                Time("SerialPi", () => SerialPi());
                Time("NaiveParallelPi", () => NaiveParallelPi());
                Time("ParallelPi", () => ParallelPi());
                Time("ParallelPartitionerPi", () => ParallelPartitionerPi());

                Time("SerialLinqPi", () => SerialLinqPi());
                Time("ParallelLinqPi", () => ParallelLinqPi());
                Time("ParallelPartitionLinqPi", () => ParallelPartitionLinqPi());

                Console.WriteLine("----");
                Console.ReadLine();
            }
        }
        catch (AggregateException ae)
        {
            foreach (var ex in ae.InnerExceptions)
                Console.WriteLine(ex.Message);
            throw;
        }
    }

    /// <summary>Times the execution of a function and outputs both the elapsed time and the function's result.</summary>
    static void Time<T>(string step, Func<T> work)
    {
        var sw = Stopwatch.StartNew();
        var result = work();
        Console.WriteLine(sw.Elapsed + ": " + result + " : " + step);
    }

    /// <summary>Estimates the value of PI using a for loop.</summary>
    static double SerialPi()
    {
        double sum = 0.0;
        double step = 1.0 / (double)num_steps;
        for (int i = 0; i < num_steps; i++)
        {
            double x = (i + 0.5) * step;
            sum = sum + 4.0 / (1.0 + x * x);
        }
        return step * sum;
    }

    /// <summary>Estimates the value of PI using a Parallel.For and naive locking approach.</summary>
    static double NaiveParallelPi()
    {
        double sum = 0.0;
        double step = 1.0 / (double)num_steps;
        object monitor = new object();
        //
        // Notes:
        // 1. Scheduler partitions N loop iterations per Task (based on default "chunk" partitioning
        // 2. Every iteration of the loop takes a lock to accumulate iteration's result into global sum.
        // 3. The cost of the lock dominates all other work in the parallel loop
        // 4. Compare to serial version performance
        //
        Parallel.For(0, num_steps, i =>
        {
            double x = (i + 0.5) * step;
            double local = 4.0 / (1.0 + x * x);
            lock (monitor) sum += local;        // Bad, locks every iteration
        });
        return step * sum;
    }

    /// <summary>Estimates the value of PI using a Parallel.For.</summary>
    static double ParallelPi()
    {
        double sum = 0.0;
        double step = 1.0 / (double)num_steps;
        object monitor = new object();
        //
        // Notes:
        // 1.  Scheduler executes N loop iterations per Task using default "chunk" partitioning
        // 2.  Lamda function is a template of the overloaded form:
        //          public static ParallelLoopResult For<TLocal>(
        //              int fromInclsive, int toExclusive,
        //              Func<TLocal> localInit,
        //              Func<int, ParallelLoopState, TLocal, Tlocal> body,
        //              Action<TLocal> localFinally);
        // 3.  Recall the template for a Action/Func as follows:
        //          ParallelLoopResult Parallel.For(int fromInclusive, int, toExclusive, Action<int, ParallelLoopState> body);
        //          ParallelLoopResult Parallel.For(int fromInclusive, int, toExclusive, Action<int, ParallelLoopState, TResult> body);
        //
        Parallel.For(0, num_steps, 
            () => 0.0,                  // localInit - runs only once per Task
            (i, state, local) =>        // For body - runs N times per Task
            {
                double x = (i + 0.5) * step;
                return local + 4.0 / (1.0 + x * x);
            }, 
            local => { lock (monitor) sum += local; });  // localFinally - runs only once per Task
        return step * sum; 
    }

    /// <summary>Estimates the value of PI using a Parallel.ForEach and a range partitioner.</summary>
    static double ParallelPartitionerPi()
    {
        double sum = 0.0;
        double step = 1.0 / (double)num_steps;
        object monitor = new object();
        // 
        // Notes:
        // 1.  Scheduler executes N partitions per Task but using a custom Partitioner instead of default "chunk".
        // 2.  Inner for loop interates over partition range elements
        //
        Parallel.ForEach(Partitioner.Create(0, num_steps),  // partition iteration space
            () => 0.0,                                      // localInit - runs once per task
            (range, state, local) =>                        // ForEach body - N partitions
            {
                for (int i = range.Item1; i < range.Item2; i++)   // inner for iterates range
                {
                    double x = (i + 0.5) * step;
                    local += 4.0 / (1.0 + x * x);
                }
                return local;
            }, 
            local => { lock (monitor) sum += local; });   // localFinally - runs once per Task
        return step * sum;
    }

    /// <summary>Estimates the value of PI using a LINQ-based implementation.</summary>
    static double SerialLinqPi()
    {
        double step = 1.0 / (double)num_steps;
        return (from i in Enumerable.Range(0, num_steps)
                let x = (i + 0.5) * step
                select 4.0 / (1.0 + x * x)).Sum() * step;
    }

    /// <summary>Estimates the value of PI using a PLINQ-based implementation.</summary>
    static double ParallelLinqPi()
    {
        // 
        // Notes:
        // 1.  PLINQ automatically collates to a single value or ToArray, ToList, ToDictionary, ToLookup
        // 2.  PLINQ can also preserve ordering in collation (not so with Parallel.ForEach)
        // 3.  PLINQ can aggregate sets of output as well as down to a single value
        // 
        double step = 1.0 / (double)num_steps;
        return (from i in ParallelEnumerable.Range(0, num_steps)
                let x = (i + 0.5) * step
                select 4.0 / (1.0 + x * x)
                ).Sum() * step;            // Sum is a PLINQ single value aggregation operator
    }

    /// <summary>Estimates the value of PI using a Hybrid PLINQ-Partition-For implementation.</summary>
    static double ParallelPartitionLinqPi()
    {
        // 
        // Notes:
        // 1.  Hybrid.  Use PLINQ to partition and for loop to create partial results.
        // 
        double step = 1.0 / (double)num_steps;
        return Partitioner.Create(0, num_steps).AsParallel().Select(range =>
        {
            double local = 0.0;
            for (int i = range.Item1; i < range.Item2; i++)
            {
                double x = (i + 0.5) * step;
                local += 4.0 / (1.0 + x * x);
            }
            return local;
        }).Sum() * step;
    }
}


//{   // PLINQ CODE SNIPPETS FOR DISCUSSION

//    var output = new List<TOutput>();
//    foreach (var item in input)
//    {
//        var result = Compute(item);
//        output.Add(result);
//    }

//    var output = input
//                    .Select(item => Compute(item))
//                    .ToList();

//    var output = input.AsParallel()
//                    .Select(item => Compute(item))
//                    .ToList();

//    var output = input.AsParallel().AsOrdered()
//                    .Select(item => Compute(item))
//                    .ToList();
//}