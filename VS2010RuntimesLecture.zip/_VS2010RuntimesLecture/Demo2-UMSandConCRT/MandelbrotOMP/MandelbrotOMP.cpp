// MandelbrotOMP.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"


#include <iostream>

using namespace std; 

#define TRADITIONALDLL_API __declspec(dllexport)

//exported APIs to make it callable from the managed code.

extern "C" {
   TRADITIONALDLL_API double ompMandelbrot(int *a, int dim, int maxIter, double minReal, double minImaginary, double maxReal);
}
extern "C" {
   TRADITIONALDLL_API double guidedOmpMandelbrot(int *a, int dim, int maxIter, double minReal, double minImaginary, double maxReal);
}


#include <stdio.h>
#include <tchar.h>
#include <intrin.h>
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <omp.h>
#include <time.h>
#include <concrt.h>
#include <ppl.h>
#include <agents.h>


/// <summary>
/// Calculates the fractal value in the c,d position in the complex space and sets the color to a[c][d].
/// </summary>
/// <param name="c">row of bitmap</param>
/// <param name="d">column of bitmap</param>
/// <param name="a"> Shared array</param>
/// <param name="len">size of array</param>
/// <param name="maxIter">Value of infinity</param>
/// <param name="minReal">Mandelbrot complex space minimum value for real component</param>
/// <param name="minImaginary">Mandelbrot complex space minimum value for imaginary component</param>
/// <param name="maxReal">Mandelbrot complex space max value for real component</param>
/// <param name="overlay">whether to apply a color coded mask to show which processor did the work</param>
/// <returns>wall clock time taken to complete the operation</returns>
void setMandelbrotColor(int c, int d, __inout_xcount(dim*dim)int *a, int dim, int maxIter, double minReal, double minImaginary, double maxReal, int showOverlay = 0)
{
	//Z(n)=Z(n-1)*Z(n-1) + C      where C=x+yi
	a = (a + (d*dim) +c);
	double x0 = c;
	double y0 = d;
	double maxImaginary=minImaginary+(maxReal-minReal);

	double realScale =(maxReal-minReal)/(dim-1);
	double imaginaryScale=(maxImaginary-minImaginary)/(dim-1);
	
	x0 = minReal + x0*realScale;
	y0 = minImaginary + y0*imaginaryScale;

	double x = x0 ;
	double y = y0 ;
    double x2 = x * x;
	double y2 = y * y;

	int iter = 0;
	while (( x2 + y2 < 4 ) && iter < maxIter) 
	{
		y = (2 * x * y)   + y0;
		x = (x2 - y2) + x0;
		x2 = x*x;
		y2 = y*y;
		iter++;
	}
    
    //if (showOverlay == 1)
    //{
    //    //*a=iter * (4294967295/maxIter);
    //    if (iter >= maxIter)
    //        *a=0xFF000000;           //black
    //    else  
    //    {
    //        unsigned short redYellowComponent = iter * 32000/maxIter ;
    //        unsigned int xx = 0x00FFF000;  //0 Alpha + RED
    //        xx =  xx|redYellowComponent;
    //        xx <<= 16;
    //        *a = xx;
    //    }

    //    ////add-overlay: 
    //    volatile int vProcId = (int) Concurrency::Context::CurrentContext()->VirtualProcessorId();
    //    vProcId+=2; //THIS IS DONE BECAUSE, we also use the main thread whose vProc value is -1.
    //    unsigned int alphaComponent = 0x00000080 | (vProcId * (128 / numVProc));
    //    alphaComponent <<= 24;
    //    unsigned int blueComponent = 0x00000080 | (vProcId * (32000 / numVProc));;

    //    *a = *a | blueComponent;

    //    //different way to calculate color ....
    //    //
    //    //blueComponent <<= 3;
    //    //*a = *a & 0x00FFFFFF; //wipe out alpha
    //    //*a = *a | alphaComponent;
    //}
    //else
    {
        //*a=iter * (4294967295/maxIter);
        if (iter >= maxIter)
            *a=0xFF000000;           //black
        else  //a gradient from red to yellow
        {
            unsigned short redYellowComponent = ~(iter * 32000/maxIter) ;
            unsigned int xx = 0x00FFF000;  //0 Alpha + RED
            xx =  xx|redYellowComponent;
            xx <<= 8;
            *a = xx;
        }
    }


    //different way to calculate color ....
    //
    //volatile int vProcId = Concurrency::VProcId();
    //vProcId++; //THIS IS DONE BECAUSE, we also use the main thread whose vProc value is -1.
    //unsigned int alphaComponent = 0x00000080 | (vProcId * (128 / numVProc));
    //alphaComponent <<= 24;
    //*a = *a & 0x00FFFFFF; //wipe out alpha
    //*a = *a | alphaComponent;
}

/// <summary>
/// Performs mandelbrot using openmp for loops using static scheduling
/// </summary>
/// <param name="a"> Shared array</param>
/// <param name="len">size of array</param>
/// <param name="maxIter">Value of infinity</param>
/// <param name="minReal">Mandelbrot complex space minimum value for real component</param>
/// <param name="minImaginary">Mandelbrot complex space minimum value for imaginary component</param>
/// <param name="maxReal">Mandelbrot complex space max value for real component</param>
/// <returns>wall clock time taken to complete the operation</returns>
double ompMandelbrot(int *a, int dim, int maxIter, double minReal, double minImaginary, double maxReal)
{
	volatile clock_t start, finish;
    start = clock();

    #pragma omp parallel for 
    for (int i = 0; i < dim; ++i)
		for (int j=0; j<dim; ++j)
           setMandelbrotColor(j,i,a,dim,maxIter, minReal, minImaginary, maxReal);
    finish = clock();
    return (double(finish-start)/CLOCKS_PER_SEC);
}

/// <summary>
/// Performs mandelbrot using openmp for loops using guided scheduling
/// </summary>
/// <param name="a"> Shared array</param>
/// <param name="len">size of array</param>
/// <param name="maxIter">Value of infinity</param>
/// <param name="minReal">Mandelbrot complex space minimum value for real component</param>
/// <param name="minImaginary">Mandelbrot complex space minimum value for imaginary component</param>
/// <param name="maxReal">Mandelbrot complex space max value for real component</param>
/// <returns>wall clock time taken to complete the operation</returns>
double guidedOmpMandelbrot(int *a, int dim, int maxIter, double minReal, double minImaginary, double maxReal)
{
	volatile clock_t start, finish;
    start = clock();

    #pragma omp parallel for schedule(guided)
    for (int i = 0; i < dim; ++i)
		for (int j=0; j<dim; ++j)
           setMandelbrotColor(j,i,a,dim,maxIter, minReal, minImaginary, maxReal);
    finish = clock();
    return (double(finish-start)/CLOCKS_PER_SEC);
}