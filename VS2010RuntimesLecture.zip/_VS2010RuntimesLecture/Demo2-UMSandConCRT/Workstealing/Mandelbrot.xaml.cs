﻿
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Runtime.InteropServices;
using System.Windows.Threading;
using System.Threading;
using System.IO;
namespace Workstealing
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class ImagingUI : Window
    {
        /// <summary>
        /// Struct for encapsulating interop with unmanaged dlls.
        /// Mandelbrot1.dll and Mandelbrot2.dll uses identical code, 
        /// but are linked against different openmp implementations. 
        /// Mandelbrot2 uses the openmp live that is built on top of concRT, 
        /// while Mandelbrot1.dll links against the standard openmp.
        /// </summary>
        struct Mandelbrot1
        {
            [DllImport(@".\MandelbrotCPP.dll")]
            extern static public double seqMandelbrot(
                [MarshalAs(UnmanagedType.LPArray)]byte[] a, int len, int maxIter, double minReal, double minImaginary, double maxReal);

            [DllImport(@".\MandelbrotCPP.dll")]
            extern static public double parMandelbrot(
                [MarshalAs(UnmanagedType.LPArray)]byte[] a, int len, int maxIter, double minReal, double minImaginary, double maxReal, int showOverlay);

            [DllImport(@".\MandelbrotCPP.dll")]
            extern static public double parUmsMandelbrot(
                [MarshalAs(UnmanagedType.LPArray)]byte[] a, int len, int maxIter, double minReal, double minImaginary, double maxReal, int showOverlay);

        };

        struct Mandelbrot2
        {
            [DllImport(@".\MandelbrotOMP.dll")]
            extern static public double ompMandelbrot(
                [MarshalAs(UnmanagedType.LPArray)]byte[] a, int len, int maxIter, double minReal, double minImaginary, double maxReal);

            [DllImport(@".\MandelbrotOMP.dll")]
            extern static public double guidedOmpMandelbrot(
                [MarshalAs(UnmanagedType.LPArray)]byte[] a, int len, int maxIter, double minReal, double minImaginary, double maxReal);
        };

        //paint info

        /// <summary>
        /// this array is shared to the unmanaged dlls.  The unmanaged dlls apply the mandelbrot algo and calculate the fillArray values. 
        /// Displaying this array as a bitmap, will in effect display all the values that are calculated. 
        /// Displaying this while it is being calculated will show the animation as to how it is being filled.
        /// </summary>
        byte[] fillArray;
        const int dim = 1000; //array size. always assume a square painting surface
        PixelFormat pf = PixelFormats.Bgra32;


        bool done = false; //whether the delgated operation is done or not

        //mandelbrot complex geometry space
        double minReal;
        double maxReal;
        double minImaginary;
        double maxImaginary;
        double realScale;       //scales are used to map a fixed integer based bitmap width to a small complex double space
        double imaginaryScale;

        //maxIter defines the interpretative value of infinity in mandelbrot1.dll. 
        //Larget the maxIter, longer the execution.
        int maxIter;

        //recording timetaken
        double timeTaken;
        double sequentialTime;
        double concRTTime;
        double concRTUmsTime;
        double ompTime;
        double guidedOmpTime;


        // delegates used for asynchronously updating/displaying the fillArray.
        // Note: threads can not be used as WPF does not allow other threads to share its data structure
        // TODO: Rpatil: find work arounds, since delegates dont deploy well.
        public delegate void MandelDelegate();
        public delegate void UpdateDelegate();

        enum RadioSelection { Sequential, ConcRTNormal, ConcRTOverlay, ConcRTUms, OpenMP, GuidedOpenMP };
        RadioSelection state; //workaround for accessing the radiobutton state (because of multithreading and WPF issues). 

        int renderCount = 0;
        /// <summary>
        /// Resets the drawing area to white, and the scales in mandelbrot complex space.
        /// </summary>
        private void resetFill()
        {
            int width = dim;
            int height = dim;
            int rawStride = (width * pf.BitsPerPixel + 7) / 8;
            fillArray = new byte[rawStride * height];
            for (int i = 0, index = 0; i < dim; ++i)
            {
                for (int j = 0; j < dim; ++j)
                {
                    //White
                    fillArray[index++] = 255;
                    fillArray[index++] = 255;
                    fillArray[index++] = 255;
                    fillArray[index++] = 255;
                }
            }

            minReal = -1.5; //default real range for our graph
            maxReal = 1.0;
            minImaginary = -1.0; //default imaginary range for our graph
            maxImaginary = minImaginary + (maxReal - minReal);

            //scales are used to map a fixed integer based bitmap width to a small complex double space
            realScale = (maxReal - minReal) / (dim - 1);
            imaginaryScale = (maxImaginary - minImaginary) / (dim - 1);

            //Coord.Text = minReal.ToString() + "," + minImaginary.ToString() + "," + maxReal.ToString() + "," + maxImaginary.ToString();
        }

        /// <summary>
        /// paint the rectangle with using the fillArray.
        /// </summary>
        private void setRectBackground()
        {
            int rawStride = (dim * pf.BitsPerPixel + 7) / 8;
            BitmapSource bitmap = BitmapSource.Create(dim, dim,
                        96, 96, pf, null,
                        fillArray, rawStride);
            ImageBrush ib = new ImageBrush(bitmap);
            rect.Fill = ib;
        }

        /// <summary>
        /// As long as the delegated async operation is not complete, continue to paint the Rectangle with the current fillArray.
        /// This is what makes the animated fill of the rectangle possible.
        /// </summary>
        private void updateBackground()
        {

            setRectBackground();
            updateClocks();
            if (!done)
            {
                if (renderCount++ % 100 == 0) System.GC.GetTotalMemory(true);
                show.Dispatcher.BeginInvoke(DispatcherPriority.Render, new MandelDelegate(updateBackground));
            }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        public ImagingUI()
        {
            InitializeComponent();
            resetFill();
            setRectBackground();
            //Mandelbrot1.init();  //TODO: Openmp already initializes the scheduler. 
            //The programming model is not clear around init.
            // Calling init twice will bring the app down unexectedly. Disabling for now.

        }


        /// <summary>
        /// Based on the selected radiobutton, call the appropriate unmanaged operation.
        /// </summary>
        private void doMandelbrot()
        {
            switch (state)
            {
                case RadioSelection.Sequential:
                    sequentialTime = timeTaken = Mandelbrot1.seqMandelbrot(fillArray, dim, maxIter, minReal, minImaginary, maxReal);
                    break;
                case RadioSelection.ConcRTNormal:
                    concRTTime = timeTaken = Mandelbrot1.parMandelbrot(fillArray, dim, maxIter, minReal, minImaginary, maxReal, 0);
                    break;
                case RadioSelection.ConcRTUms:
                    concRTUmsTime = timeTaken = Mandelbrot1.parUmsMandelbrot(fillArray, dim, maxIter, minReal, minImaginary, maxReal, 0);
                    break;
                case RadioSelection.ConcRTOverlay:
                    concRTTime = timeTaken = Mandelbrot1.parMandelbrot(fillArray, dim, maxIter, minReal, minImaginary, maxReal, 1);
                    break;
                case RadioSelection.OpenMP:
                    ompTime = timeTaken = Mandelbrot2.ompMandelbrot(fillArray, dim, maxIter, minReal, minImaginary, maxReal);
                    break;
                case RadioSelection.GuidedOpenMP:
                    guidedOmpTime = timeTaken = Mandelbrot2.guidedOmpMandelbrot(fillArray, dim, maxIter, minReal, minImaginary, maxReal);
                    break;
            }
            Thread.Sleep(1000); //Without explicit long sleep, there seems to be an rendering update issue. 
            done = true;
        }

        /// <summary>
        /// Event handler when the show button is clicked.
        /// 1. Sets up the state by looking at the radiobutton group.
        /// 2. Parses the max iteration - goes yellow on error, but continues with an assumption.
        /// 3. Creates a delegate to process the mandelbrot fractals asynchnronously
        /// </summary>
        private void OnShowClicked(object sender, RoutedEventArgs e)
        {
            if (rbSeq.IsChecked.Value == true)
            {
                state = RadioSelection.Sequential;
            }
            else if (rbConcrt.IsChecked.Value == true)
            {
                state = RadioSelection.ConcRTNormal;
            }
            else if (rbConcrtUms.IsChecked.Value == true)
            {
                state = RadioSelection.ConcRTUms;
            }
            else if (rbOmp.IsChecked.Value == true)
            {
                state = RadioSelection.OpenMP;
            }
            else if (rbGuidedOmp.IsChecked.Value == true)
            {
                state = RadioSelection.GuidedOpenMP;
            }


            try
            {
                maxIter = Int32.Parse(iteration.Text);
                iteration.Background = Brushes.LightGray;
            }
            catch (Exception)
            {
                maxIter = 1000;
                iteration.Background = Brushes.LightYellow;
            }

            done = false;
            MandelDelegate sd = new MandelDelegate(doMandelbrot);
            sd.BeginInvoke(null, null);
            updateBackground();
        }

        /// <summary>
        /// reset all the measurements and times to zero
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void resetClocks(object sender, RoutedEventArgs e)
        {
            timeTaken = 0;
            sequentialTime = 0;
            concRTTime = 0;
            concRTUmsTime = 0;
            ompTime = 0;
            guidedOmpTime = 0;
            updateClocks();
        }

        /// <summary>
        /// updated text boxes using the time variables
        /// </summary>
        private void updateClocks()
        {
            try
            {
                seqTimeText.Text = sequentialTime.ToString();
                concTimeText.Text = concRTTime.ToString();
                concUmsTimeText.Text = concRTUmsTime.ToString();
                ompTimeText.Text = ompTime.ToString();
                guidedOmpTimeText.Text = guidedOmpTime.ToString();

                // SequentialTime vs....

                // ConcRT UMS
                if (sequentialTime == 0 || concRTUmsTime == 0)
                {
                    concrtUMSSpeedup.Text = "N/A";
                }
                else
                {
                    concrtUMSSpeedup.Text = (sequentialTime / concRTUmsTime).ToString();
                }

                // Static OMP
                if (sequentialTime == 0 || ompTime == 0)
                {
                    staticOMPSpeedup.Text = "N/A";
                }
                else
                {
                    staticOMPSpeedup.Text = (sequentialTime / ompTime).ToString();
                }

                // Guided OMP
                if (sequentialTime == 0 || guidedOmpTime == 0)
                {
                    guidedOMPSpeedup.Text = "N/A";
                }
                else
                {
                    guidedOMPSpeedup.Text = (sequentialTime / guidedOmpTime).ToString();
                }

                // ConcRT Thread-Pool
                if (sequentialTime == 0 || concRTTime == 0)
                {
                    concrtThreadSpeedup.Text = "N/A";
                }
                else
                {
                    concrtThreadSpeedup.Text = (sequentialTime / concRTTime).ToString();
                }
            }
            catch (Exception)
            {
                concrtUMSSpeedup.Text = "Err";
                staticOMPSpeedup.Text = "Err";
                guidedOMPSpeedup.Text = "Err";
                concrtThreadSpeedup.Text = "Err";
            }

        }

        /// <summary>
        /// Event handler - Clears the painted area by painting it with white
        /// </summary>
        private void OnClearPaintClicked(object sender, RoutedEventArgs e)
        {
            resetFill();
            setRectBackground();
        }


        /// <summary>
        /// Event handler
        /// Double clicking left mouse button in the paint area zooms in and recalculates mandelbrot fractals with the new complex space values
        /// </summary>
        private void ZoomIn(object sender, RoutedEventArgs r)
        {
            MouseButtonEventArgs e = r as MouseButtonEventArgs;
            if (e.ClickCount == 2)
            {
                Point p = e.GetPosition(rect);

                //Step 1: Translate Center
                double diffReal = ((p.X * (dim / rect.Width) * realScale) + minReal) - ((maxReal + minReal) / 2);
                double diffImaginary = ((p.Y * (dim / rect.Height) * imaginaryScale) + minImaginary) - ((maxImaginary + minImaginary) / 2);
                minReal = minReal + diffReal;
                maxReal = maxReal + diffReal;
                minImaginary = minImaginary + diffImaginary;
                maxImaginary = maxImaginary + diffImaginary;

                //Step 2: Zoom in
                double zoomFactor = zoomSlider.Value;

                minReal = minReal + zoomFactor / (dim / rect.Width) * realScale;
                minImaginary = minImaginary + zoomFactor / (dim / rect.Height) * imaginaryScale;
                maxReal = maxReal - zoomFactor / (dim / rect.Width) * realScale;
                maxImaginary = minImaginary + (maxReal - minReal);
                Coord.Text = minReal.ToString() + "," + minImaginary.ToString() + "," + maxReal.ToString() + "," + maxImaginary.ToString();

                realScale = (maxReal - minReal) / (dim - 1);
                imaginaryScale = (maxImaginary - minImaginary) / (dim - 1);

                OnShowClicked(null, null);

            }

        }

        /// <summary>
        /// Event handler
        /// Single clicking right mouse button in the paint area zooms out and recalculates mandelbrot fractals with the new complex space values
        /// </summary>
        private void ZoomOut(object sender, RoutedEventArgs r)
        {
            double zoomOutFactor = zoomSlider.Value;

            minReal = minReal - zoomOutFactor / (dim / rect.Width) * realScale;
            minImaginary = minImaginary - zoomOutFactor / (dim / rect.Height) * imaginaryScale;
            maxReal = maxReal + zoomOutFactor / (dim / rect.Width) * realScale;
            maxImaginary = minImaginary + (maxReal - minReal);
            Coord.Text = minReal.ToString() + "," + minImaginary.ToString() + "," + maxReal.ToString() + "," + maxImaginary.ToString();

            realScale = (maxReal - minReal) / (dim - 1);
            imaginaryScale = (maxImaginary - minImaginary) / (dim - 1);
            OnShowClicked(null, null);

        }

        /// <summary>
        /// Event handler to reset clocks
        /// </summary>
        private void ResetClocks(object sender, RoutedEventArgs r)
        {
            resetClocks(null, null);
        }
    }

}
