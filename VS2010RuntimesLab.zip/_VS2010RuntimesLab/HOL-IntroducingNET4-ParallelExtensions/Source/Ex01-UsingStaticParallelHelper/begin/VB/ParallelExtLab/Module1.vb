﻿Imports System.Threading
Imports System.Threading.Tasks

Module Module1

    Sub Main()
        Console.ReadLine()
    End Sub

End Module
